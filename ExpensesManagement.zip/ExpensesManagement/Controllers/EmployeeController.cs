﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExpensesManagement.Models;

namespace ExpensesManagement.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        Training_12DecMumbaiEntities5 db = new Training_12DecMumbaiEntities5();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult EmployeeHome()
        {

            return View();

        }
        [Authorize(Roles = "Supervisor,Employee")]
        [HttpPost, ActionName("EmployeeHome")]

        public ActionResult EmployeeHome(FormCollection fc)
        {
            Employee employee = new Employee();

            string value = fc["submit"];
            int a = Convert.ToInt32(fc["EmployeeId"]);

            //employee = db.Employees.Find(a);
            switch (value)
            {
                case "Details":
                    return Redirect("EmployeeDetails/" + a); //(EmployeeDetails(a));
                case "Edit":
                    return Redirect("EmployeeEdit/" + a); //(EmployeeDetails(a));
                    //return (EmployeeEdit(a));

            }


            return View();

        }
        public ActionResult EmployeeEdit() {      //{
        //    TempData["EmpId"] = id;
        //    TempData.Keep();

        //    Employee employee = db.Employees.Find(id);
        //    return View(employee);
        Employee emp = (Employee)Session["userStudent"];
        TempData["employeeId"] = emp.EmployeeId;
            TempData["Name"] = emp.Name;
            TempData["DateOfJoining"] = emp.DateOfJoining;
            TempData["Location"] = emp.Location;
            TempData["Department"] = emp.Department;
            TempData["Experience"] = emp.Experience;
            TempData["Role"] = emp.Role;
            TempData["Username"] = emp.Username;
            TempData.Keep();
            return View(emp);

    }
        [Authorize(Roles = "Supervisor,Employee")]
        [HttpPost, ActionName("EmployeeEdit")]
        public ActionResult EmployeeEdit(FormCollection fc)
        {

            Employee employee = new Employee();
            employee.EmployeeId = Convert.ToInt32(TempData["employeeId"]);
            employee.Name = fc["Name"];
            employee.DateOfJoining = DateTime.Parse(fc["DateOfJoining"]);
            employee.Location = fc["Location"];
            employee.Department = fc["Department"];
            employee.Experience = Convert.ToInt32(fc["Experience"]);
            employee.Role = fc["Role"];
            employee.Username = TempData["Username"].ToString();
            //[Bind(Include = "studentId,studentName,emailId,phoneNumber,password,address,courseId,departmentId,gender,academicYear,percentage,attendance")]
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;

                try

                {

                    db.SaveChanges();
                    Session["userStudent"] = employee;

                }

                catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException ex)

                {
                    ex.Entries.Single().Reload();

                    db.SaveChanges();

                }
                   
                Session["userStudent"] = employee;
                return RedirectToAction("EmployeeHome");
            }
           // ViewBag.courseId = new SelectList(db.Courses, "courseId", "courseName", student.courseId);
           // ViewBag.departmentId = new SelectList(db.Departments, "departmentId", "departmentName", student.departmentId);
            return View(employee);
           
        }


        }
        

    }

