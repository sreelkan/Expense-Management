﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExpensesManagement.Models;
namespace ExpensesManagement.Controllers
{
    public class ReceiptController : Controller
    {
        Training_12DecMumbaiEntities5 db = new Training_12DecMumbaiEntities5();
        // GET: Receipt
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddReceipt()
        {
            Employee emp = (Employee)Session["userStudent"];
            TempData["employeeId"] = emp.EmployeeId;
            Receipt newRecord = new Receipt();
            newRecord.EmployeeId = Convert.ToInt32(TempData["employeeId"]);
            TempData.Keep();
           
            return View(newRecord);
        }
        [HttpPost]
        public ActionResult AddReceipt(HttpPostedFileBase file, FormCollection form)
        {
            Employee employee = new Employee();
           
            Receipt newRecord = new Receipt();
            newRecord.ReceiptNumber = Convert.ToInt32(form["ReceiptNumber"]);
            newRecord.ReceiptDate = DateTime.Parse(form["ReceiptDate"]);
            //TempData["employeeId"] = emp.EmployeeId;
            newRecord.ReceiptAmount = Convert.ToInt32(form["ReceiptAmount"]);
            employee.EmployeeId= Convert.ToInt32(TempData["employeeId"]);
            newRecord.EmployeeId = employee.EmployeeId;
           // newRecord.EmployeeId = employee.EmployeeId;
            if (file != null)
            {
                string ImageName = System.IO.Path.GetFileName(file.FileName);
                string physicalPath = Path.Combine(Server.MapPath("~/Image/" + ImageName));

                // save image in folder
                file.SaveAs(physicalPath);

                newRecord.ReceiptUrl = ImageName;
                //newRecord.Category = Request.Form["Category"];
                //newRecord.ReceiptAmount = Convert.ToInt32(Request.Form["ReceiptAmount"]);
                db.Receipts.Add(newRecord);
              //  Session["userStudent"] = newRecord;
                db.SaveChanges();

            }
            //Display records
            return RedirectToAction("ViewReceipts");
        }

        public ActionResult ViewReceipts()
        {
            Employee student = (Employee)Session["userStudent"];
                 var id = student.EmployeeId;
            //Receipt receipt = db.Receipts.Find(id);

            
            var receiptSession = (from p in db.Receipts where student.EmployeeId == p.EmployeeId select p).ToList();
            
            
            List<Receipt> studentList = (List<Receipt>)receiptSession;
            //List<Student> studentList = db.Students.Where(db);
            return View(studentList);
            

        }

    }
}